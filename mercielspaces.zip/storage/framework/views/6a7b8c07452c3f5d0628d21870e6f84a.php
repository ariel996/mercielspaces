<?php $__env->startSection('title', 'About'); ?>
<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumb
        ============================================= -->
    <div class="breadcrumb-area bg-cover shadow dark text-center text-light" style="background-image: url(/assets/img/banner/10.jpg);">
        <div class="breadcrum-shape">
            <img src="/assets/img/shape/50.png" alt="Image Not Found">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12">
                    <h1>Contact Us</h1>
                    <ul class="breadcrumb">
                        <li><a href=""><i class="fas fa-home"></i> Home</a></li>
                        <li>About</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumb -->
    <!-- Start About
============================================= -->
    <div class="about-style-one-area default-padding">
        <div class="shape-animated-left">
            <img src="/assets/img/shape/anim-1.png" alt="Image Not Found">
            <img src="/assets/img/shape/anim-2.png" alt="Image Not Found">
        </div>
        <div class="container">
            <div class="row align-center">
                <div class="about-style-one col-xl-6 col-lg-5">
                    <div class="h4 sub-heading">Feel Valued & Rewarded</div>
                    <h2 class="title mb-25">Finance Consulting for Challenging Times</h2>
                    <?php echo $about?->description; ?>

                    <div class="owner-info">
                        <div class="left-info">
                            <h4><?php echo e($about?->author); ?></h4>
                            <span><?php echo e($about?->fonction); ?></span>
                        </div>
                        <div class="right-info">
                            <img src="<?php echo e(asset('storage/'.$about?->signature)); ?>" alt="Image Not Found">
                        </div>
                    </div>
                </div>
                <div class="about-style-one col-xl-5 offset-xl-1 col-lg-6 offset-lg-1">
                    <div class="about-thumb">
                        <img class="wow fadeInRight" src="<?php echo e(asset('storage/'.$about?->image)); ?>" alt="<?php echo e($about?->author); ?>">
                        <div class="about-card wow fadeInUp" data-wow-delay="500ms">
                            <ul>
                                <li>
                                    <div class="icon">
                                        <i class="flaticon-license"></i>
                                    </div>
                                    <div class="fun-fact">
                                        <div class="counter">
                                            <div class="timer" data-to="98" data-speed="2000">98</div>
                                            <div class="operator">%</div>
                                        </div>
                                        <span class="medium">Consulting Success</span>
                                    </div>
                                </li>
                                <li>
                                    <div class="icon">
                                        <i class="flaticon-global"></i>
                                    </div>
                                    <div class="fun-fact">
                                        <div class="counter">
                                            <div class="timer" data-to="120" data-speed="2000">120</div>
                                            <div class="operator">+</div>
                                        </div>
                                        <span class="medium">Worldwide Clients</span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                        <div class="thumb-shape-bottom wow fadeInDown" data-wow-delay="300ms">
                            <img src="/assets/img/shape/anim-3.png" alt="Image Not Found">
                            <img src="/assets/img/shape/anim-4.png" alt="Image Not Found">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End About -->

    <!-- Start Partner Area
    ============================================= -->
    <div class="partner-style-one-area default-padding">
        <div class="container">
            <div class="row align-center">
                <div class="col-lg-5">
                    <div class="partner-map" style="background-image: url(/assets/img/shape/map.png);">
                        <h2 class="mask-text" style="background-image: url(/assets/img/banner/10.jpg);"><?php echo e(count($partners)); ?></h2>
                        <h4>Partners in world wide</h4>
                    </div>
                </div>
                <div class="col-lg-6 offset-lg-1">
                    <div class="partner-items">
                        <ul>
                            <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><img src="<?php echo e(asset('storage/'.$partner->partner_img)); ?>" alt="Image Not FOund"></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Partner Area -->

    <!-- Start Team
    ============================================= -->
    <div class="team-style-onea-rea default-padding-top pb-70 pb-xs-0 bg-contain-center bg-gray" style="background-image: url(/assets/img/shape/18.png);">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="site-heading text-center">
                        <h4 class="sub-heading">Team Members</h4>
                        <h2 class="title">Meet our experts</h2>
                        <div class="devider"></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <!-- Single Item -->
                <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-3 col-md-6">
                        <div class="team-style-one <?php echo e($team->id === 1 ? 'active' : ''); ?>">
                            <div class="thumb">
                                <img src="<?php echo e(asset('storage/'.$team->image_path)); ?>" alt="<?php echo e($team->name); ?> Not Found">
                                <div class="social">
                                    <ul>
                                        <?php if($team->facebook_link != ""): ?>
                                            <li class="facebook">
                                                <a href="<?php echo e($team->facebook_link); ?>">
                                                    <i class="fab fa-facebook-f"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>

                                        <?php if($team->twitter_link != ""): ?>
                                            <li class="twitter">
                                                <a href="<?php echo e($team->twitter_link); ?>">
                                                    <i class="fab fa-twitter"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>

                                        <?php if($team->linkedin_link != ""): ?>
                                            <li class="linkedin">
                                                <a href="<?php echo e($team->linkedin_link); ?>">
                                                    <i class="fab fa-linkedin-in"></i>
                                                </a>
                                            </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </div>
                            <div class="info">
                                <span><?php echo e($team->fonction); ?></span>
                                <h4><a href="#"><?php echo e($team->name); ?></a></h4>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- End Single Item -->
            </div>
        </div>
    </div>
    <!-- End Team Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ariel-nana/Projets/projets/mercielspaces/resources/views/about.blade.php ENDPATH**/ ?>